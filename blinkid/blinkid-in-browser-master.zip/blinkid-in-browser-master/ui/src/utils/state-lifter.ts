/**
 * Copyright (c) Microblink Ltd. All rights reserved.
 */
export const globalState = {
  isPassport: false,
};
