# mb-container



<!-- Auto Generated Below -->


## Dependencies

### Used by

 - [blinkid-in-browser](../../blinkid-in-browser)

### Graph
```mermaid
graph TD;
  blinkid-in-browser --> mb-container
  style mb-container fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
