/**
 * Copyright (c) Microblink Ltd. All rights reserved.
 */

import MicroblinkWorker from "./MicroblinkSDK/worker/MicroblinkSDK.worker";

new MicroblinkWorker();
