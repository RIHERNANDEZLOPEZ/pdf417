/**
 * Copyright (c) Microblink Ltd. All rights reserved.
 */


/**
 * The side of the document.
 */
export enum DocumentSide
{
    Front,
    Back,
}
