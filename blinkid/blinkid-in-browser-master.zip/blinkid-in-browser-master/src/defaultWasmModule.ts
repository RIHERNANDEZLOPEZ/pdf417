/**
 * Copyright (c) Microblink Ltd. All rights reserved.
 */

export const defaultWasmModuleName = "BlinkIDWasmSDK";
export const nativeJsonizationEnabled = true;
