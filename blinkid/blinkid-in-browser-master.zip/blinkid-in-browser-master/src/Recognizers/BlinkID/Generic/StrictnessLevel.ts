/**
 * Copyright (c) Microblink Ltd. All rights reserved.
 */

export enum StrictnessLevel
{
    Strict  = 0,
    Normal  = 1,
    Relaxed = 2
}
