/**
 * Copyright (c) Microblink Ltd. All rights reserved.
 */


export enum ImageExtractionType {
    FullDocument,
    Face,
    Signature
}
